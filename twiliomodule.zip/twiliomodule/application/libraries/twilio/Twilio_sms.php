<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
class Twilio_sms
{

    private $CI;
    private $AccountSid='';
    private $AuthToken='';
    private $from_sender='';

	public function __construct( $config = array() )
	{
		$this->CI =& get_instance();
		
		// Load config file
		$this->CI->config->load('twilio_sms', TRUE);
		
		foreach( $this->CI->config->item('twilio_sms') as $key => $value )
		{
			if( isset($this->$key) )
			{
				$this->$key = $value;
			}
		}

		$this->initialize($config);
	}

	// Initialize the lib
	public function initialize( $config )
	{
		foreach( $config as $key => $value )
		{
			if( isset($this->$key) )
			{
				$this->$key = $value;
			}
		}
	}

public function sendSMS($mobilenumber,$msg){
require('Services/Twilio.php');
//$AccountSid = "ACcf352af4335446802ac2046b988ccb1e";
//$AuthToken = "8858fdae6e074c168fd4b03f67977302";
try {
$http = new Services_Twilio_TinyHttp(
'https://api.twilio.com',
array('curlopts' => array(
CURLOPT_SSL_VERIFYPEER => false,
CURLOPT_SSL_VERIFYHOST => 2,
)));
$client = new Services_Twilio($this->AccountSid,$this->AuthToken, "2010-04-01",
$http);
$from =$this->from_sender;
$to = '+91'.$mobilenumber;
// The SMS body
$message = $msg;
// Send a new outgoing SMS
$response = $client->account->sms_messages->create($from, $to, $message);

// Get the delivery status
//return $response->status;

} catch (Exception $e) {
echo "Caught exception: " . $e->getMessage();
}

}


}