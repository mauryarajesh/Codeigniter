<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// Twilio SMS Account Info
$config['AccountSid'] = 'ACcf352af4335446802wsde3c2046b988ccb1e';
$config['AuthToken'] = '8858fdae6e074c16823wb03f67977302';
$config['from_sender'] = '+13072981231'; // TEST URL

/* EOF */