<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
 * Example usage of Authorize.net's
 * Advanced Integration Method (AIM)
 */
class Twilio extends CI_Controller
{

    public function __construct(){
	parent::__construct(); 
    $this->load->library('twilio/twilio_sms');
	}
 
 
 public function otp(){
    $this->twilio_sms->sendSMS('+918447951972','testing'); 
 }



  
}

/* EOF */